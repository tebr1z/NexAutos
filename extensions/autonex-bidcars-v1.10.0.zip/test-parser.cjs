"use strict";

const assert = require("node:assert/strict");
const parser = require("./parser.js");

const lot = parser.parseSnapshot({
  title: "2022 HYUNDAI SONATA, SEL PLUS 5NPEJ4J29NH148698 IAAI",
  text: `
    Current Bid $2,200 USD Your max bid --- Time left 0 d 0 h 36 min 35 sec $5,000 Bid Now
    Final Price Calculator Lot Price $5,000 Auction Fees $925 Trucking to port $270
    Location: Savannah (GA) Shipping from: Savannah (GA) Estimated cost: $4,160 - $7,420
    Body Style Sedan Exterior color Blue Engine 1.6L, 4 cyl. Transmission Automatic
    Fuel Type Gasoline Drive Type Front wheel drive
  `,
  exactTokens: ["IAAI"],
  bidCandidates: [{ value: "$5,000", score: 20, kind: "bidNow" }, { value: "$2,200", score: 2 }],
});

assert.equal(lot.priceUsd, 5000);
assert.equal(lot.bidNowUsd, 5000);
assert.equal(lot.currentBidUsd, 2200);
assert.equal(lot.lotPriceUsd, 5000);
assert.equal(lot.auctionFeeUsd, 925);
assert.equal(lot.auction, "IAAI");
assert.equal(lot.location, "Savannah (GA)");
assert.equal(lot.state, "GA");
assert.equal(lot.year, 2022);
assert.equal(lot.engineCc, 1600);
assert.equal(lot.fuel, "Gasoline");
assert.equal(lot.fuelCode, "1");
assert.equal(parser.fuelCode("Diesel"), "2");
assert.equal(parser.fuelCode("Electric"), "12");
assert.equal(parser.normalizeFuel("Hybrid Electric"), "Hybrid");
assert.equal(parser.normalizeFuel("Battery Electric Vehicle (BEV)"), "Electric");
assert.equal(parser.normalizeFuel("Diesel"), "Diesel");
assert.equal(parser.normalizeFuel("Diesel Hybrid"), "Diesel hybrid");
assert.equal(parser.normalizeFuel("Plug-in Hybrid Electric Vehicle (PHEV)"), "Plug-in hybrid");
assert.equal(parser.normalizeFuel("Plug-in Diesel Hybrid"), "Plug-in diesel hybrid");
assert.equal(parser.normalizeFuel("Mild Hybrid Diesel"), "Mild diesel hybrid");
assert.equal(parser.fuelCode(parser.normalizeFuel("Hybrid Electric")), "6");
assert.equal(parser.fuelCode(parser.normalizeFuel("Battery Electric Vehicle (BEV)")), "12");
assert.equal(parser.fuelCode(parser.normalizeFuel("Diesel")), "2");
assert.equal(parser.fuelCode(parser.normalizeFuel("Diesel Hybrid")), "7");
assert.equal(parser.fuelCode(parser.normalizeFuel("Plug-in Hybrid Electric Vehicle (PHEV)")), "8");
assert.equal(parser.fuelCode(parser.normalizeFuel("Plug-in Diesel Hybrid")), "10");
assert.equal(parser.fuelCode(parser.normalizeFuel("Mild Hybrid Diesel")), "13");
assert.equal(parser.parseEngineCc("2.0L4"), 2000);
assert.equal(parser.parseEngineCc("2,0 L I4"), 2000);
assert.equal(parser.parseEngineCc("3.6L-V6"), 3600);
assert.equal(parser.parseEngineCc("1998 cc"), 1998);
assert.equal(parser.parseEngineCc("1998 cubic centimeters"), 1998);
assert.equal(parser.parseEngineCc("Electric"), null);

const visibleSpecsWinOverHiddenMenu = parser.parseSnapshot({
  title: "2021 KIA K5, GT LINE",
  text: `
    Search & Bid Engine size, type, horsepower Type Electric Hybrid Gasoline Diesel
    Location: Freetown (MA) Shipping from: Newark (NJ)
    Exterior color Gray Engine 2.0L Transmission Automatic Fuel Type Hybrid
  `,
  auctionHint: "Copart",
  engineLabel: "1.6L, 4 cyl.",
  fuel: "Gasoline",
});
assert.equal(visibleSpecsWinOverHiddenMenu.engineCc, 1600);
assert.equal(visibleSpecsWinOverHiddenMenu.engineLabel, "1.6L, 4 cyl.");
assert.equal(visibleSpecsWinOverHiddenMenu.fuel, "Gasoline");
assert.equal(visibleSpecsWinOverHiddenMenu.fuelCode, "1");
assert.equal(visibleSpecsWinOverHiddenMenu.vin, "");

const compactEngineLot = parser.parseSnapshot({
  title: "2016 HYUNDAI SONATA, LIMITED KMHE54L29GA021523",
  text: "Location: Freetown (MA)",
  engineLabel: "2.0L4",
});
assert.equal(compactEngineLot.engineCc, 2000);
assert.equal(compactEngineLot.vin, "KMHE54L29GA021523");

const dieselSpecs = parser.parseSnapshot({
  title: "2020 TEST CAR",
  text: "Location: Dallas (TX)",
  engineLabel: "2.2L, 4 cyl.",
  fuel: "Diesel",
});
assert.equal(dieselSpecs.engineCc, 2200);
assert.equal(dieselSpecs.fuelCode, "2");

const electricSpecs = parser.parseSnapshot({
  title: "2024 TEST EV",
  text: "Location: Dallas (TX)",
  engineLabel: "Electric",
  fuel: "Electric",
});
assert.equal(electricSpecs.engineCc, null);
assert.equal(electricSpecs.fuelCode, "12");

const liveBid = parser.parseSnapshot({
  title: "2022 HYUNDAI SONATA IAAI",
  text: `
    Time left Live auction in progress $2,700 Bid Now
    Final Price Estimator Lot Price $2,700 Auction Fees $720 Trucking to port $270
    Location: Savannah (GA) Engine 2.0L Fuel Type Gasoline Drive Type Front wheel drive
  `,
  exactTokens: ["IAAI"],
  bidCandidates: [{ value: "$2,700", score: 20, kind: "bidNow" }],
});

assert.equal(liveBid.bidNowUsd, 2700);
assert.equal(liveBid.lotPriceUsd, 2700);
assert.equal(liveBid.auctionFeeUsd, 720);

const copartFromBody = parser.parseSnapshot({
  title: "2020 Toyota Camry",
  text: "Location: Dallas (TX) Auction Copart Engine 2.5L Fuel Type Gasoline",
  exactTokens: [],
  bidCandidates: [{ value: "$3,100", score: 20, kind: "bidNow" }],
});
assert.equal(copartFromBody.auction, "COPART");

const copartBadgeWins = parser.parseSnapshot({
  title: "2016 HYUNDAI SONATA, LIMITED",
  text: "Copart and IAAI vehicles Location: Freetown (MA)",
  auctionHint: "Copart",
  exactTokens: ["IAAI", "Copart"],
  bidCandidates: [{ value: "$8,400", score: 20, kind: "bidNow" }],
});
assert.equal(copartBadgeWins.auction, "COPART");

const iaaiBadgeWins = parser.parseSnapshot({
  title: "2021 KIA K5",
  text: "Copart and IAAI vehicles Location: Orlando South (FL)",
  auctionHint: "IAAI",
  exactTokens: ["Copart", "IAAI"],
  bidCandidates: [{ value: "$12,500", score: 20, kind: "bidNow" }],
});
assert.equal(iaaiBadgeWins.auction, "IAAI");
assert.deepEqual(
  parser.selectAuctionFee({ priceUsd: 2700, bidCarsFeeUsd: 720, bidNowUsd: 2700, lotPriceUsd: 2700, fallbackFeeUsd: 860 }),
  { amount: 720, source: "BidCars" },
);
assert.deepEqual(
  parser.selectAuctionFee({ priceUsd: 2200, bidCarsFeeUsd: 720, bidNowUsd: 2700, lotPriceUsd: 2700, fallbackFeeUsd: 785 }),
  { amount: 785, source: "Auto Nex fallback" },
);

console.log("BidCars parser tests passed.");
